# Kensi Linux Build Instructions

## ENGLISH

1. Install Arch Linux
2. Install archiso:
   pacman -S archiso
3. Copy this skeleton:
   cp -r kensi-skeleton ~/
4. Build ISO:
   mkarchiso -v kensi-iso
5. Write to USB:
   dd if=out/kensi*.iso of=/dev/sdX bs=4M status=progress oflag=sync
6. Test in VM (QEMU/VirtualBox)

## РУССКИЙ

1. Установите Arch Linux
2. Установите archiso:
   pacman -S archiso
3. Скопируйте шаблон:
   cp -r kensi-skeleton ~/
4. Соберите ISO:
   mkarchiso -v kensi-iso
5. Запишите на флешку:
   dd if=out/kensi*.iso of=/dev/sdX bs=4M status=progress oflag=sync
6. Протестируйте в виртуальной машине

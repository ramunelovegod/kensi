#!/bin/bash
set -e -u

useradd -m -G wheel,network,storage,power -s /bin/bash kensi
echo "kensi:live" | chpasswd
echo "root:live" | chpasswd

echo "kensi ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers

cat > /etc/lightdm/lightdm.conf << EOF
[Seat:*]
autologin-user=kensi
autologin-session=xfce
EOF

systemctl enable lightdm
systemctl enable NetworkManager
systemctl enable tor

cp /etc/iptables/rules.v4 /etc/iptables/iptables.rules
systemctl enable iptables

cp /root/usb-watchdog.sh /usr/local/bin/usb-watchdog.sh
chmod +x /usr/local/bin/usb-watchdog.sh
cp /root/kensi-sanity-check.sh /usr/local/bin/kensi-sanity-check.sh
chmod +x /usr/local/bin/kensi-sanity-check.sh
cp /root/create-persistent.sh /usr/local/bin/create-persistent.sh
chmod +x /usr/local/bin/create-persistent.sh

systemctl enable usb-watchdog.service
systemctl enable kensi-sanity.service

echo "net.ipv6.conf.all.disable_ipv6=1" >> /etc/sysctl.d/99-ipv6.conf
echo "net.ipv6.conf.default.disable_ipv6=1" >> /etc/sysctl.d/99-ipv6.conf

systemctl mask systemd-resolved
rm -f /etc/systemd/system/multi-user.target.wants/bluetooth.service 2>/dev/null || true

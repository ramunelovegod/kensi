#!/bin/bash
sleep 5

if ip -6 addr show | grep -q "inet6"; then
    zenity --error --text="IPv6 активен! Это угроза анонимности. Отключаемся."
    exit 1
fi

if ! dig +short ifconfig.me | grep -qE '^[0-9.]+$'; then
    zenity --error --text="DNS утекает в обход Tor! Запуск сети запрещён."
    exit 1
fi

zenity --info --text="Kensi: проверка пройдена. Анонимность обеспечена."

#!/bin/bash
ROOT_DEV=$(findmnt -n -o SOURCE /run/archiso/cowspace | sed 's/\[.*\]//' | sed 's/[0-9]*$//')
USB_DEV=$(lsblk -no pkname $ROOT_DEV | head -1)

if [ -z "$USB_DEV" ]; then
    exit 1
fi

udevadm monitor --udev -s block | while read -r line; do
    if echo "$line" | grep -q "$USB_DEV" && echo "$line" | grep -q "remove"; then
        systemctl stop tor
        umount /home/kensi/Persistent 2>/dev/null || true
        cryptsetup close kensi-persist 2>/dev/null || true
        iptables -P INPUT DROP
        iptables -P OUTPUT DROP
        iptables -F
        reboot -f
    fi
done

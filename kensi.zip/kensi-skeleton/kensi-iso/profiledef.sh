#!/usr/bin/env bash
iso_name="kensi"
iso_label="KENSI_$(date +%Y%m)"
iso_publisher="Kensi Project"
iso_application="Kensi Linux Live/Rescue CD"
iso_version="$(date +%Y.%m.%d)"
build_date="$(date +%Y.%m.%d)"
install_dir="arch"
bootmodes=('bios.syslinux.mbr' 'bios.syslinux.eltorito' 'uefi-x64.systemd-boot.esp' 'uefi-x64.systemd-boot.eltorito')
arch="x86_64"
pacman_conf="pacman.conf"
airootfs_image_type="squashfs"
airootfs_image_tool_options=('-comp' 'xz' '-Xbcj' 'x86' '-b' '1M' '-Xdict-size' '1M')
file_permissions=(
  "/etc/shadow|0|0|600"
  "/root/customize_airootfs.sh|0|0|755"
  "/root/usb-watchdog.sh|0|0|755"
  "/root/kensi-sanity-check.sh|0|0|755"
  "/root/create-persistent.sh|0|0|755"
)
